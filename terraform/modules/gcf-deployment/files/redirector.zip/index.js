let httpProxy = require('http-proxy'),
    ip = require('ip');

let proxy = httpProxy.createProxyServer({secure: false});

let host = "tumblr.com"
let target = "https://tumblr.com"


let frontedDomain = "https://google.com"
let restrictUA = ""
let restrictSubnet = ""
let restrictHeader = ""
let restrictValue = ""


exports.redirector = (req, res) => {
  	let requestIP = req.connection.remoteAddress
 

    if ((req.Method == "GET") || (req.Method == "POST")) {
        if ((restrictUA != "") && (restrictUA != req.getHeader('User-Agent'))) {
            res.redirect(frontedDomain)
            return
        }
        if ((restrictSubnet != "") && (!ip.cidrSubnet(restrictSubnet).Contains(requestIP))) {
            res.redirect(frontedDomain) 
            return
        }
        if ((restrictHeader != "") && (req.getHeader(restrictHeader) != restrictValue)){
          res.redirect(frontedDomain)
          return
        }
    
        req.host = host
        proxy.web(req, res, { target: target });
    } else {
        res.redirect(frontedDomain)
    }
};
